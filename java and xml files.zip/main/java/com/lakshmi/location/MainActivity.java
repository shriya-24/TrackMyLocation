package com.lakshmi.location;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements LocationListener {

    Button getLocationBtn;
    TextView locationText;

    Double lat1 = 0.0;
    Double longt1 = 0.0;

    LocationManager locationManager;
    final String[] output = {""};
    final String filename = "location";
    String tempoutput="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        getLocationBtn = (Button)findViewById(R.id.button1);
        locationText = (TextView)findViewById(R.id.textView1);



        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);

        }


        getLocationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLocation();
            }
        });
    }

    void getLocation() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000, 10, this);
        }
        catch(SecurityException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        locationText.setText("\n Latitude: " + location.getLatitude() + "\n Longitude: " + location.getLongitude());

        Double lat = location.getLatitude();
        Double lon = location.getLongitude();
        try {
            String dt;
            Date cal = Calendar.getInstance().getTime();
            dt = cal.toLocaleString();
            tempoutput="\n\nDate and Time: "+dt;
            tempoutput=tempoutput+"\nLatitude: " + location.getLatitude() + " Longitude: " + location.getLongitude()+"\n";
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            locationText.setText(locationText.getText() + "\n"+addresses.get(0).getAddressLine(0));
            tempoutput=tempoutput+addresses.get(0).getAddressLine(0);
            System.out.println("tempoutput"+tempoutput);
            output[0]=output[0].concat(tempoutput);


            //System.out.println(addresses);
            FileOutputStream outputStream;

            try {
                outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                outputStream.write(output[0].getBytes());
                outputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

            if(lat!=lat1 && lon!=longt1 )
            {
                //System.out.println("Location changed");
                Message.message(getApplicationContext(),"Location Changed");
                lat1=lat;
                longt1=lon;
                sendSMS("9833632087",output[0]);

            }

        }catch(Exception e)
        {

        }

        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {

            File f1 = Environment.getExternalStorageDirectory();
            File dir = new File(f1.getAbsolutePath()+"/LocationApp");
            if (!dir.exists()) {
                    boolean success =dir.mkdirs();
                System.out.println(success+"------"+dir);
            }

            File file = new File(dir, "location.txt");
            try {
        /*FileOutputStream fo = new FileOutputStream(file);
        fo.write(message.getBytes());
        fo.close();*/
                BufferedWriter writer = new BufferedWriter(new FileWriter(file, true /*append*/));
                writer.write(tempoutput);
                //writer.write(message1);
                writer.close();
                //Toast.makeText(getBaseContext(), "Data Saved", Toast.LENGTH_LONG).show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else
            Toast.makeText(getBaseContext(), "Not avail", Toast.LENGTH_LONG).show();

    }
    public void sendSMS(String phoneNo, String msg) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNo, null, msg, null, null);
            Toast.makeText(getApplicationContext(), "Message Sent",
                    Toast.LENGTH_LONG).show();
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(),ex.getMessage().toString(),
                    Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }


    @Override
    public void onProviderDisabled(String provider) {
        Toast.makeText(MainActivity.this, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }
}

